import json
import os

from qgis.PyQt.QtCore import QTimer, Qt
from qgis.PyQt.QtGui import QIcon
try:
    from qgis.PyQt.QtGui import QAction
except ImportError:
    from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QToolButton,
    QVBoxLayout,
    QWidget,
)
from qgis.core import (
    QgsCoordinateTransform,
    QgsExpression,
    QgsFeatureRequest,
    QgsProject,
    QgsRectangle,
    QgsVectorLayer,
)


SETTING_FILENAME = "KK_Quick_Attribute_Jump_Setting.json"
DEFAULT_SETTINGS = {
    "layer_id": "",
    "layer_name": "",
    "field_name": "",
    "always_open": False,
    "button_font_size": 20,
    "table_row_height": 20,
}


def _enum_value(owner, group, value):
    enum_group = getattr(owner, group, owner)
    return getattr(enum_group, value)


class CollapsibleSection(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.toggle = QToolButton()
        self.toggle.setText(title)
        self.toggle.setCheckable(True)
        self.toggle.setChecked(True)
        self.toggle.setToolButtonStyle(
            _enum_value(Qt, "ToolButtonStyle", "ToolButtonTextBesideIcon")
        )
        self.toggle.setArrowType(_enum_value(Qt, "ArrowType", "DownArrow"))
        self.toggle.setStyleSheet("QToolButton { border: none; font-weight: bold; }")

        self.content = QWidget()
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(8, 4, 8, 8)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.toggle)
        layout.addWidget(self.content)
        self.toggle.toggled.connect(self._set_expanded)

    def _set_expanded(self, expanded):
        self.content.setVisible(expanded)
        self.toggle.setArrowType(
            _enum_value(Qt, "ArrowType", "DownArrow" if expanded else "RightArrow")
        )


class LayerComboBox(QComboBox):
    def __init__(self, refresh_callback, parent=None):
        super().__init__(parent)
        self.refresh_callback = refresh_callback

    def showPopup(self):
        self.refresh_callback()
        super().showPopup()


class CategoryTableDialog(QDialog):
    def __init__(
        self, iface, layer, field_name, category_value, display, row_height, parent=None
    ):
        super().__init__(parent)
        self.iface = iface
        self.layer = layer
        self.features = []
        self.setWindowTitle("{}: {}".format(field_name, display))
        self.resize(900, 520)

        layout = QVBoxLayout(self)
        self.table = QTableWidget(self)
        self.table.setColumnCount(len(layer.fields()))
        self.table.setHorizontalHeaderLabels(layer.fields().names())
        self.table.setSelectionBehavior(
            _enum_value(QAbstractItemView, "SelectionBehavior", "SelectRows")
        )
        self.table.setSelectionMode(
            _enum_value(QAbstractItemView, "SelectionMode", "SingleSelection")
        )
        self.table.setEditTriggers(
            _enum_value(QAbstractItemView, "EditTrigger", "NoEditTriggers")
        )
        self.table.verticalHeader().setDefaultSectionSize(row_height)
        self.table.horizontalHeader().setSectionResizeMode(
            _enum_value(QHeaderView, "ResizeMode", "ResizeToContents")
        )
        layout.addWidget(self.table)
        self._populate(field_name, category_value)
        self.table.itemSelectionChanged.connect(self._zoom_selected_feature)

    def _populate(self, field_name, category_value):
        if category_value is None:
            expression = "{} IS NULL".format(
                QgsExpression.quotedColumnRef(field_name)
            )
        else:
            expression = "{} = {}".format(
                QgsExpression.quotedColumnRef(field_name),
                QgsExpression.quotedValue(category_value),
            )
        request = QgsFeatureRequest().setFilterExpression(expression)
        rows = list(self.layer.getFeatures(request))
        self.features = rows
        self.table.setRowCount(len(rows))
        for row_index, feature in enumerate(rows):
            for column_index, field in enumerate(self.layer.fields()):
                value = feature.attribute(field.name())
                item = QTableWidgetItem("" if value is None else str(value))
                if column_index == 0:
                    item.setData(_enum_value(Qt, "ItemDataRole", "UserRole"), feature.id())
                self.table.setItem(row_index, column_index, item)

    def _zoom_selected_feature(self):
        row = self.table.currentRow()
        if row < 0 or row >= len(self.features):
            return
        feature = self.features[row]
        if not feature.hasGeometry():
            return
        canvas = self.iface.mapCanvas()
        extent = feature.geometry().boundingBox()
        if self.layer.crs() != canvas.mapSettings().destinationCrs():
            transform = QgsCoordinateTransform(
                self.layer.crs(),
                canvas.mapSettings().destinationCrs(),
                QgsProject.instance(),
            )
            extent = transform.transformBoundingBox(extent)
        if extent.isEmpty():
            return
        width = extent.width()
        height = extent.height()
        current = canvas.extent()
        padding_x = width * 0.2 if width else current.width() * 0.025
        padding_y = height * 0.2 if height else current.height() * 0.025
        extent = QgsRectangle(
            extent.xMinimum() - padding_x,
            extent.yMinimum() - padding_y,
            extent.xMaximum() + padding_x,
            extent.yMaximum() + padding_y,
        )
        canvas.setExtent(extent)
        canvas.refresh()


class KKQuickAttributeJump:
    def __init__(self, iface):
        self.iface = iface
        self.dialog = None
        self.action = None
        self.category_dialogs = []
        self.settings = dict(DEFAULT_SETTINGS)
        self._load_settings()
        QgsProject.instance().readProject.connect(self._on_project_read)

    def initGui(self):
        self.action = QAction("KK_Quick_Attribute_Jump", self.iface.mainWindow())
        self.action.setIcon(QIcon(os.path.join(os.path.dirname(__file__), "icon.svg")))
        self.action.triggered.connect(self._show_dialog)
        self.iface.addPluginToMenu("KK_Quick_Attribute_Jump", self.action)
        self.iface.addToolBarIcon(self.action)
        if self.settings["always_open"]:
            self._show_dialog()

    def unload(self):
        QgsProject.instance().readProject.disconnect(self._on_project_read)
        if self.action is not None:
            self.iface.removePluginMenu("KK_Quick_Attribute_Jump", self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action = None
        if self.dialog is not None:
            self.dialog.close()
            self.dialog = None
        for dialog in list(self.category_dialogs):
            dialog.close()
        self.category_dialogs.clear()

    def _settings_path(self):
        project_path = QgsProject.instance().fileName()
        if not project_path:
            return None
        return os.path.join(os.path.dirname(project_path), SETTING_FILENAME)

    def _load_settings(self):
        path = self._settings_path()
        if path is None or not os.path.isfile(path):
            return False
        try:
            with open(path, "r", encoding="utf-8") as settings_file:
                data = json.load(settings_file)
        except (OSError, json.JSONDecodeError) as error:
            self._show_error("設定ファイルを読み込めませんでした。\n{}".format(error))
            return False
        if not isinstance(data, dict):
            self._show_error("設定ファイルの形式が正しくありません。")
            return False
        self.settings.update(
            {key: data[key] for key in DEFAULT_SETTINGS if key in data}
        )
        self.settings["button_font_size"] = self._valid_integer(
            self.settings["button_font_size"], 20, 6, 72
        )
        self.settings["table_row_height"] = self._valid_integer(
            self.settings["table_row_height"], 20, 8, 100
        )
        self.settings["always_open"] = bool(self.settings["always_open"])
        return True

    def _save_settings(self):
        path = self._settings_path()
        if path is None:
            self._show_error("プロジェクトを保存してから設定を保存してください。")
            return
        if self.dialog is not None:
            selected_layer_id = self.layer_combo.currentData()
            selected_layer = (
                QgsProject.instance().mapLayer(selected_layer_id)
                if selected_layer_id
                else None
            )
            self.settings.update(
                {
                    "layer_id": selected_layer.id() if selected_layer else "",
                    "layer_name": selected_layer.name() if selected_layer else "",
                    "field_name": self.field_combo.currentData() or "",
                    "always_open": self.always_open.isChecked(),
                    "button_font_size": self.font_size.value(),
                    "table_row_height": self.row_height.value(),
                }
            )
        try:
            with open(path, "w", encoding="utf-8") as settings_file:
                json.dump(self.settings, settings_file, ensure_ascii=False, indent=2)
        except OSError as error:
            self._show_error("設定ファイルを保存できませんでした。\n{}".format(error))
            return
        QMessageBox.information(self.dialog, "設定保存", "設定を保存しました。")

    def _show_dialog(self, *_args):
        if self.dialog is None:
            self.dialog = self._create_dialog()
        self._refresh_layers()
        self._apply_button_style()
        self.dialog.show()
        self.dialog.raise_()
        self.dialog.activateWindow()

    def _create_dialog(self):
        dialog = QDialog(self.iface.mainWindow())
        dialog.setWindowTitle("KK_Quick_Attribute_Jump")
        dialog.setWindowFlag(
            _enum_value(Qt, "WindowType", "WindowStaysOnTopHint"),
            True,
        )
        dialog.setMinimumWidth(300)
        layout = QVBoxLayout(dialog)

        self.place_button = QPushButton("場所を探す")
        self.place_button.clicked.connect(self._show_categories)
        layout.addWidget(self.place_button)

        self.layer_section = CollapsibleSection("レイヤ設定")
        self.layer_combo = LayerComboBox(self._refresh_layers)
        self.field_combo = QComboBox()
        self.layer_combo.currentIndexChanged.connect(self._on_layer_changed)
        self.layer_section.content_layout.addWidget(QLabel("検索するレイヤ"))
        self.layer_section.content_layout.addWidget(self.layer_combo)
        self.layer_section.content_layout.addWidget(QLabel("検索する属性"))
        self.layer_section.content_layout.addWidget(self.field_combo)
        layer_save = QPushButton("設定保存")
        layer_save.clicked.connect(self._save_settings)
        self.layer_section.content_layout.addWidget(layer_save)
        layout.addWidget(self.layer_section)

        self.display_section = CollapsibleSection("表示設定")
        self.always_open = QCheckBox("常に表示する")
        self.always_open.setChecked(self.settings["always_open"])
        self.font_size = QSpinBox()
        self.font_size.setRange(6, 72)
        self.font_size.setValue(self.settings["button_font_size"])
        self.row_height = QSpinBox()
        self.row_height.setRange(8, 100)
        self.row_height.setValue(self.settings["table_row_height"])
        self.display_section.content_layout.addWidget(self.always_open)
        self.display_section.content_layout.addWidget(QLabel("ボタンの文字サイズ"))
        self.display_section.content_layout.addWidget(self.font_size)
        self.display_section.content_layout.addWidget(
            QLabel("属性テーブルの行の高さ")
        )
        self.display_section.content_layout.addWidget(self.row_height)
        display_save = QPushButton("設定保存")
        display_save.clicked.connect(self._save_settings)
        self.display_section.content_layout.addWidget(display_save)
        layout.addWidget(self.display_section)

        self.font_size.valueChanged.connect(self._apply_button_style)
        return dialog

    def _refresh_layers(self, prefer_settings=False):
        if self.dialog is None:
            return
        selected_field = (
            self.settings.get("field_name", "")
            if prefer_settings
            else self.field_combo.currentData() or self.settings.get("field_name", "")
        )
        selected_id = (
            self.settings.get("layer_id", "")
            if prefer_settings
            else self.layer_combo.currentData()
        )
        if not selected_id:
            selected_id = self.settings.get("layer_id", "")
        layers = []
        for node in QgsProject.instance().layerTreeRoot().findLayers():
            layer = node.layer()
            if isinstance(layer, QgsVectorLayer) and layer.isValid():
                layers.append(layer)
        self.layer_combo.blockSignals(True)
        self.layer_combo.clear()
        for layer in layers:
            self.layer_combo.addItem(layer.name(), layer.id())
        target_index = self.layer_combo.findData(selected_id)
        if target_index < 0:
            target_index = self.layer_combo.findText(self.settings.get("layer_name", ""))
        if target_index >= 0:
            self.layer_combo.setCurrentIndex(target_index)
        self.layer_combo.blockSignals(False)
        self._on_layer_changed(preferred_field=selected_field)

    def _on_layer_changed(self, *_args, preferred_field=None):
        if self.dialog is None:
            return
        layer_id = self.layer_combo.currentData()
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        self.field_combo.blockSignals(True)
        self.field_combo.clear()
        if isinstance(layer, QgsVectorLayer):
            for field in layer.fields():
                self.field_combo.addItem(field.name(), field.name())
            field_name = preferred_field or self.settings.get("field_name", "")
            target = self.field_combo.findData(field_name)
            if target >= 0:
                self.field_combo.setCurrentIndex(target)
        self.field_combo.blockSignals(False)

    def _show_categories(self):
        layer_id = self.layer_combo.currentData()
        field_name = self.field_combo.currentData()
        layer = QgsProject.instance().mapLayer(layer_id) if layer_id else None
        if not isinstance(layer, QgsVectorLayer) or not field_name:
            self._show_error("検索するレイヤと属性を選択してください。")
            return

        categories = {}
        for feature in layer.getFeatures():
            value = feature.attribute(field_name)
            display = "(NULL)" if value is None else str(value)
            key = (type(value).__name__, repr(value))
            categories.setdefault(key, (display, value))
        if not categories:
            self._show_error("検索対象の地物がありません。")
            return

        category_dialog = QDialog(self.dialog)
        category_dialog.setWindowTitle("場所を探す")
        category_dialog.setWindowFlag(
            _enum_value(Qt, "WindowType", "WindowStaysOnTopHint"),
            True,
        )
        category_dialog.resize(320, 500)
        layout = QVBoxLayout(category_dialog)
        scroll = QScrollArea(category_dialog)
        scroll.setWidgetResizable(True)
        button_panel = QWidget()
        button_layout = QVBoxLayout(button_panel)
        button_layout.setContentsMargins(4, 4, 4, 4)
        for display, value in sorted(
            categories.values(), key=lambda item: item[0].casefold()
        ):
            button = QPushButton(display)
            self._style_button(button)
            button.clicked.connect(
                lambda _checked=False, selected=value, text=display: self._show_table(
                    layer, field_name, selected, text
                )
            )
            button_layout.addWidget(button)
        button_layout.addStretch(1)
        scroll.setWidget(button_panel)
        layout.addWidget(scroll)
        self.category_dialogs.append(category_dialog)
        category_dialog.finished.connect(
            lambda _result, closed=category_dialog: self._forget_category_dialog(closed)
        )
        category_dialog.show()

    def _show_table(self, layer, field_name, value, display):
        table_dialog = CategoryTableDialog(
            self.iface,
            layer,
            field_name,
            value,
            display,
            self.row_height.value(),
            self.dialog,
        )
        self.category_dialogs.append(table_dialog)
        table_dialog.finished.connect(
            lambda _result, closed=table_dialog: self._forget_category_dialog(closed)
        )
        table_dialog.show()

    def _forget_category_dialog(self, dialog):
        if dialog in self.category_dialogs:
            self.category_dialogs.remove(dialog)

    def _style_button(self, button):
        size = self.font_size.value()
        button.setStyleSheet(
            "QPushButton {{ font-size: {}px; padding: {}px 8px; }}".format(
                size, max(4, size // 3)
            )
        )
        button.setMinimumHeight(size * 2)

    def _apply_button_style(self, *_args):
        if not hasattr(self, "place_button"):
            return
        self._style_button(self.place_button)
        for dialog in self.category_dialogs:
            for button in dialog.findChildren(QPushButton):
                self._style_button(button)

    def _on_project_read(self, *_args):
        if self.dialog is None or not self.always_open.isChecked():
            return
        QTimer.singleShot(0, self._reload_project_settings)

    def _reload_project_settings(self):
        if self._load_settings() and self.dialog is not None:
            self.always_open.setChecked(self.settings["always_open"])
            self.font_size.setValue(self.settings["button_font_size"])
            self.row_height.setValue(self.settings["table_row_height"])
            self._refresh_layers(prefer_settings=True)
            self._apply_button_style()

    @staticmethod
    def _valid_integer(value, default, minimum, maximum):
        try:
            return max(minimum, min(maximum, int(value)))
        except (TypeError, ValueError):
            return default

    @staticmethod
    def _show_error(message):
        QMessageBox.warning(None, "KK_Quick_Attribute_Jump", message)
